import tkinter as tk
from tkinter import messagebox
import ctypes
import sys
import os

def is_admin():
    """Проверка, запущена ли программа с правами администратора"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    """Перезапуск программы с правами администратора через UAC"""
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)

def fix_hosts():
    """Добавление записи в файл hosts"""
    hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
    entry = "18.65.39.105 tr.rbxcdn.com\n"
    
    try:
        # Проверяем, есть ли уже такая запись
        with open(hosts_path, "r", encoding="utf-8") as f:
            content = f.read()
            if "tr.rbxcdn.com" in content:
                messagebox.showinfo("Информация", "Запись для tr.rbxcdn.com уже существует!")
                return
        
        # Добавляем запись
        with open(hosts_path, "a", encoding="utf-8") as f:
            f.write(entry)
        
        messagebox.showinfo("Успех", "Запись успешно добавлена в hosts файл!\n\n18.65.39.105 tr.rbxcdn.com")
        
    except PermissionError:
        messagebox.showerror("Ошибка доступа", "Не удалось записать в файл.\nЗапустите программу от имени администратора.")
    except FileNotFoundError:
        messagebox.showerror("Ошибка", "Файл hosts не найден.\nПроверьте путь: " + hosts_path)
    except Exception as e:
        messagebox.showerror("Ошибка", f"Произошла ошибка:\n{str(e)}")

def main():
    # Создаем главное окно
    root = tk.Tk()
    root.title("Fix Tool")
    root.geometry("400x250")
    root.resizable(False, False)
    root.configure(bg="#1a1a1a")
    
    # Заголовок
    title_label = tk.Label(
        root,
        text="FIX TOOL",
        font=("Arial", 20, "bold"),
        bg="#1a1a1a",
        fg="#ffffff"
    )
    title_label.pack(pady=20)
    
    # Информационный текст
    info_label = tk.Label(
        root,
        text="Нажмите кнопку для применения фикса",
        font=("Arial", 10),
        bg="#1a1a1a",
        fg="#aaaaaa"
    )
    info_label.pack()
    
    # Кнопка "Фикс"
    fix_button = tk.Button(
        root,
        text="ФИКС",
        font=("Arial", 14, "bold"),
        bg="#4a9eff",
        fg="white",
        activebackground="#3a8eef",
        activeforeground="white",
        command=fix_hosts,
        width=20,
        height=2,
        relief=tk.FLAT,
        cursor="hand2",
        borderwidth=0
    )
    fix_button.pack(pady=20)
    
    # Подпись "by - sqmoke" внизу
    author_label = tk.Label(
        root,
        text="by - sqmoke",
        font=("Arial", 10, "italic"),
        bg="#1a1a1a",
        fg="#666666"
    )
    author_label.pack(side=tk.BOTTOM, pady=15)
    
    # Запуск окна
    root.mainloop()

if __name__ == "__main__":
    # При запуске проверяем права администратора
    if not is_admin():
        # Запрашиваем права через UAC (появится стандартное окно подтверждения)
        try:
            run_as_admin()
        except Exception as e:
            # Если не получилось получить права, показываем предупреждение
            root = tk.Tk()
            root.withdraw()
            messagebox.showwarning(
                "Требуются права администратора",
                "Для работы программы необходимы права администратора.\nПожалуйста, подтвердите запрос UAC."
            )
        sys.exit(0)
    else:
        # У нас есть права администратора, запускаем приложение
        main()